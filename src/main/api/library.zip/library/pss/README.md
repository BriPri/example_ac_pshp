# Introduction 
This repository contains common RAML objects uses by most PSS Mule API's.

# Repository Intent
The intent is to pull this repository into an application as a git subtree
into the src/main/api/library directory.
