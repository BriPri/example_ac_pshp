# General Booking Sequence

![Booking](https://bitsinglass.box.com/shared/static/7kirz4bw35hg380gsbt4ihb99shb1mgh.png)
