# General Document Issuance Sequence

![Document Issuance](https://bitsinglass.box.com/shared/static/gqot3k83zjf6dbm9op7n5ha9yiue1bmv.png)
