# General Pre-Booking Validation Sequence

![Pre-check for Booking](https://bitsinglass.box.com/shared/static/s1oq2vrsdmvzv9ni1hvjkuvkrj18sbic.png)
