# Introduction 
This repository contains a translation of an OTA model into RAML form.

The model was created from the original XSD to more the model available in RAML.

The model is heavily commented out to allow for future use of the OTA model
that is not know to have immediate value.

The model is also adjusted to meet Air Canada's extension needs for vendors.

# Repository Intent
The intent is to pull this repository into an application as a git subtree
into the src/main/api/library directory.
