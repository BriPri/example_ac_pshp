# General Payment Sequence

![Payment](https://bitsinglass.box.com/shared/static/d17r70ces0e7cusirn0m4902nj5bk6w2.png)
