# General Payment Card Sequence

The payment card tokenization application is separated from the main EIP applications.

The payment card tokenization application **MUST BE** audited for PCI compliance.

All non-tokenized payment card must use this service to tokenizes before using the Payment API. 

![Payment Card](https://bitsinglass.box.com/shared/static/c6prs4i9q73wl6u501cah0yr8gyiy8eb.png)
